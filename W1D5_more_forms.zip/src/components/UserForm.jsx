import React, { useState } from 'react';


const UserForm = (props) => {
    //SETTING STATE//
    const [firstname, setFirstname] = useState("");
    const [lastname, setLastname] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    //VALIDATION "SETTERS and GETTERS"//
    const [firstnameError, setFirstnameError] = useState("");
    const [lastnameError, setLastnameError] = useState("");
    const [emailError, setEmailError] = useState("");
    const [passwordError, setPasswordError] = useState("");
    const [confirmPasswordError, setConfirmPasswordError] = useState("");
    const [isValid, setIsValid] = useState(true);

    //CREATE USER//
    const createUser = (e) =>{
        e.preventDefault();
        const newUser = {firstname, lastname, email, password};
    }
    //VALIDATION ERRORS//
    const handleFirstname = (e) => {
        setFirstname(e.target.value);
        if (e.target.value.length < 1) {
            setFirstnameError("First name required!");
            setIsValid(false)
        } else if (e.target.value.length < 3) {
            setFirstnameError("First name must be at least 3 characters!");
            setIsValid(false)
        }
        else{
            setFirstnameError("");
        }
    };
    const handleLastname = (e) => {
        setLastname(e.target.value);
        if (e.target.value.length < 1) {
            setLastnameError("Last name required!");
            setIsValid(false)
        } else if (e.target.value.length < 3) {
            setLastnameError("Last name must be at least 3 characters!");
            setIsValid(false)
        }
        else{
            setLastnameError("");
        }
    };
    const handleEmail = (e) => {
        setEmail(e.target.value);
        if (e.target.value.length < 1) {
            setEmailError("Email required!");
            setIsValid(false)
        } else if (e.target.value.length < 5) {
            setEmailError("Email must be at least 5 characters!");
            setIsValid(false);
        }
        else{
            setEmailError("");
        }
    };
    const handlePassword = (e) => {
        setPassword(e.target.value);
        if (e.target.value.length < 1) {
            setPasswordError("Password required!");
            setIsValid(false)
        } else if (e.target.value.length < 8) {
            setPasswordError("Password must be at least 8 characters!");
            setIsValid(false)
        }
        else{
            setPasswordError("");
        }
    };
    const handleConfirmPassword = (e) => {
        setConfirmPassword(e.target.value);
        if (e.target.value != password) {
            setConfirmPasswordError("Password and Confirm Password must match!");
            setIsValid(false)
        }
        else{
            setConfirmPasswordError("");
        }
    };


    return (
        <div>
            <form onSubmit={createUser}>
                <div>
                    <label>First Name: </label>
                    <input type="text" onChange={handleFirstname} />
                    {
                        firstnameError ?
                            <p style={{ color: 'red' }}>{firstnameError}</p> :
                            ''
                    }

                </div>
                <div>
                    <label>Last Name: </label>
                    <input type="text" onChange={handleLastname} />
                    {
                        lastnameError ?
                            <p style={{ color: 'red' }}>{lastnameError}</p> :
                            ''
                    }
                </div>
                <div>
                    <label>Email Address: </label>
                    <input type="text" onChange={handleEmail} />
                    {
                        emailError ?
                            <p style={{ color: 'red' }}>{emailError}</p> :
                            ''
                    }
                </div>
                <div>
                    <label>Password: </label>
                    <input type="text" onChange={handlePassword} />
                    {
                        passwordError ?
                            <p style={{ color: 'red' }}>{passwordError}</p> :
                            ''
                    }
                </div>
                <div>
                    <label>Confirm Password: </label>
                    <input type="text" onChange={handleConfirmPassword} />
                    {
                        confirmPasswordError ?
                            <p style={{ color: 'red' }}>{confirmPasswordError}</p> :
                            ''
                    }
                </div>
                <input type="submit" value="Create User" />
            </form>
            <div>
                <p>First Name: {firstname}</p>
                <p>Last Name:  {lastname}</p>
                <p>Email:  {email}</p>
                <p>Password:  {password}</p>
            </div>
        </div>
    );
};


export default UserForm;