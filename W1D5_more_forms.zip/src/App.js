import logo from './logo.svg';
import UserForm from './components/UserForm';
import './App.css';

function App() {
  
  return (
  <body>
      <div className="App-header">
        <UserForm/>
      </div>
  </body>
  );
}
      

export default App;
